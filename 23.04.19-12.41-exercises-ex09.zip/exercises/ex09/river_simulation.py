"""File to construct my_river."""

from exercises.ex09.river import River

my_river: River = River(10, 2)
my_river.view_river()
